#include "StochasticNum64.h"

using namespace stochastic;

StochasticNum64::StochasticNum64()
{
}
StochasticNum64::StochasticNum64(long long bits)
{
	m_bits = bits;

}
StochasticNum64::StochasticNum64(double value, bool isneg)
{
	uint8_t x;
	double rng;
		m_bits = 0;
		for (int j = 0; j < 64; j++)
		{
			x = xor8();
			rng = (double)x * 0.0039;
			if (rng < value)
				m_bits |= ((long long)1 << j);
		}
	m_bits &= 0xFFFFFFFFFFFFFFFE;
	m_bits |= (long long)isneg;
}
StochasticNum64::StochasticNum64(double value, bool isneg, int flag)
{
	if (flag == 1)
	{
		uint8_t x;
		double rng;
		m_bits = 0;
		for (int j = 0; j < 64; j++)
		{
			x = xor8();
			rng = (double)x * 0.0039;
			if (rng < value)
				m_bits |= ((long long)1 << j);
		}
		m_bits &= 0xFFFFFFFFFFFFFFFE;
		m_bits |= (long long)isneg;
	}
	else
	{
		uint8_t x;
		double rng;
		m_bits = 0;
		for (int j = 0; j < 64; j++)
		{
			x = xor8();
			rng = (double)x * 0.0039;
			if (rng < value)
				m_bits |= ((long long)1 << j);
		}
		m_bits &= 0xFFFFFFFFFFFFFFFE;
		m_bits |= (long long)isneg;
	}
}
void StochasticNum64::setValue(double value, bool isneg)
{
	uint8_t x;
	double rng;
	m_bits = 0;
	for (int j = 0; j < 64; j++)
	{
		x = xor8();
		rng = (double)x * 0.0039;
		if (rng < value)
			m_bits |= ((long long)1 << j);
	}
	m_bits &= 0xFFFFFFFFFFFFFFFE;
	m_bits |= (long long)isneg;
}
void StochasticNum64::setValue(double value, bool isneg, int flag)
{
	if (flag == 1)
	{
		uint8_t x;
		double rng;
		m_bits = 0;
		for (int j = 0; j < 64; j++)
		{
			x = xor8();
			rng = (double)x * 0.0039;
			if (rng < value)
				m_bits |= ((long long)1 << j);
		}
		m_bits &= 0xFFFFFFFFFFFFFFFE;
		m_bits |= (long long)isneg;
	}
	else
	{
		uint8_t x;
		double rng;
		m_bits = 0;
		for (int j = 0; j < 64; j++)
		{
			x = xor8();
			rng = (double)x * 0.0039;
			if (rng < value)
				m_bits |= ((long long)1 << j);
		}
		m_bits &= 0xFFFFFFFFFFFFFFFE;
		m_bits |= (long long)isneg;
	}
}
const StochasticNum64 StochasticNum64::add(StochasticNum64& other, StochasticNum64& select)
{
	long long bits;
	bits = (other.m_bits &= ~select.m_bits) | (m_bits &= select.m_bits);

	return StochasticNum64(bits);
}