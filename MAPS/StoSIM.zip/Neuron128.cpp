#include "Neuron128.h"
#include <cstddef>
using namespace stochastic;

extern "C" short popcount(short val1, short val2);

Neuron128::Neuron128()
{
	m_input = NULL;
	m_weight = NULL;
	m_bias = NULL;
}
Neuron128::~Neuron128()
{
	delete[] m_input;
	delete[] m_bias;
	delete[] m_weight;
	delete m_onehalf;
}
void Neuron128::setInput(StochasticNum128* input)
{
	m_input = input;
}
void Neuron128::setBias(double* biases)
{
	m_bias = biases;
}
void Neuron128::setWeight(StochasticNum128* weights)
{
	m_weight = weights;
}

void Neuron128::assignOneHalf(double* half)
{
	m_onehalf = half;
}
void Neuron128::setNumWeights(int num)
{
	m_numweights = num;
}
double Neuron128::think()
{
	short total = 0;
	for (int i = 0; i < m_numweights; i++)
	{
		StochasticNum128 c = m_input[i] * m_weight[i];
		short t = popcount(c.m_bits[0], c.m_bits[1]);
		t += popcount(c.m_bits[2], c.m_bits[3]);
		t += popcount(c.m_bits[4], c.m_bits[5]);
		t += popcount(c.m_bits[6], c.m_bits[7]);

		if ((c.m_bits[7] & (long)1) == 1)
		{
			t -=1;
			t *= -1;
		}
		total += t;
	}
	if (total < 0)
		return 0;
	//std::cout << total << std::endl;
	return (total);//StochasticNum((((total)) / 12), 128); // @12 128 47%
}