#ifndef STOCHASTICNUM_H
#define STOCHASTICNUM_H

#include <boost\dynamic_bitset.hpp>
#include "randoms.h"
#include <cassert>

namespace stochastic
{

	class StochasticNum
	{
	public:
		StochasticNum();
		StochasticNum(double value, long size = 0, bool isNeg = false);
		StochasticNum(boost::dynamic_bitset<>& bits);
		void setValue(double value, long size, bool isneg);
		double getDoubleValue() const;
		size_t getSize();
		boost::dynamic_bitset<>* getBits();
		inline const StochasticNum operator* (const StochasticNum& other)
		{
			size_t i = m_bits.size();
			StochasticNum n(m_bits);
			n.m_bits &= other.m_bits;
			n.m_bits[i - 1] = m_bits[i - 1] ^ other.m_bits[i - 1];
			return n;
		}
		const StochasticNum add(StochasticNum& other, StochasticNum& select);


	private:
		boost::dynamic_bitset<> m_bits;
		size_t m_size;
	};
}
#endif