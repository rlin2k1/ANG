#ifndef NEURON64_H
#define NEURON64_H

#include "StochasticNum64.h"
namespace stochastic
{
	class Neuron64
	{
	public:
		~Neuron64();
		Neuron64();

		void setInput(StochasticNum64* input);
		void setBias(double* biases);
		void setWeight(StochasticNum64* weights);
		void setNumWeights(int num);

		void assignOneHalf(double* half);

		double think();

	private:
		int m_numweights;
		StochasticNum64* m_input;
		double* m_bias;
		StochasticNum64* m_weight;
		double* m_onehalf;
	};
}

#endif