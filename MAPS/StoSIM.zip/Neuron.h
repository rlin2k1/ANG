#ifndef NEURON_H
#define NEURON_H

#include "StochasticNum.h"
#include <boost\dynamic_bitset.hpp>
namespace stochastic
{
	class Neuron
	{
	public:
		~Neuron();
		Neuron();

		void setInput(StochasticNum* input);
		void setBias(double* biases);
		void setWeight(StochasticNum* weights);
		void setNumWeights(int num);

		void assignOneHalf(double* half);

		double think();

	private:
		int m_numweights;
		StochasticNum* m_input;
		double* m_bias;
		StochasticNum* m_weight;
		double* m_onehalf;
	};
}

#endif