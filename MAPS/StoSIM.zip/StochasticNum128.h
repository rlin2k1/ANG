#ifndef STOCHASTICNUML_H
#define STOCHASTICNUML_H

#include "randoms.h"

extern "C" short popcount(short val1, short val2);

namespace stochastic
{

	class StochasticNum128
	{
	public:
		StochasticNum128();
		StochasticNum128(double value, bool isNeg);
		StochasticNum128(double value, bool isNeg, int flag);
		StochasticNum128(short bits[8]);
		void setValue(double value, bool isneg);
		void setValue(double value, bool isneg, int flag);
		inline double getDoubleValue() const
		{
			double total = 0;
			int neg = 1;
			total = popcount(m_bits[0], m_bits[1]);
			total += popcount(m_bits[2], m_bits[3]);
			total += popcount(m_bits[4], m_bits[5]);
			total += popcount(m_bits[6], m_bits[7]);

			if ((m_bits[7] & (long)1) == 1)
			{
				total--;
				neg = -1;
			}
			return total * 0.0078125 * (double)neg;
		}
		inline const StochasticNum128 operator* (const StochasticNum128& other)
		{
			short bits[7];
			bits[0] = m_bits[0] & other.m_bits[0];
			bits[1] = m_bits[1] & other.m_bits[1];
			bits[2] = m_bits[2] & other.m_bits[2];
			bits[3] = m_bits[3] & other.m_bits[3];
			bits[4] = m_bits[4] & other.m_bits[4];
			bits[5] = m_bits[5] & other.m_bits[5];
			bits[6] = m_bits[6] & other.m_bits[6];
			bits[7] = m_bits[7] & other.m_bits[7];

			short a = (short)1 & m_bits[7];
			short b = (short)1 & other.m_bits[7];
			bits[7] = bits[7] | (a ^ b);
			return StochasticNum128(bits);
		}
		const StochasticNum128 add(StochasticNum128& other, StochasticNum128& select);


	public:
		short m_bits[8];
	};
}
#endif