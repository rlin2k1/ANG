//Disable debug flags for speed testing
//GET ARBITRARY BIT RNG LATER

#include <iostream>
#include <fstream>
#include <limits>
#include <string>
#include <cstdlib>
#include <cstdio>
#include "NeuronD.h"
#include "Neuron64.h"
#include "Neuron128.h"
#include "StreamingNeuron.h"
#include "StochasticNum128.h"

using namespace stochastic;

const static int BIT_LENGTH = 128;
void mnist_d()
{
		std::ifstream ifile;
		ifile.open("W1.txt");

		NeuronD* layer1 = new NeuronD[100];
		//NeuronD* layer1d = new NeuronD[100];
		//Neuron* layer1s = new Neuron[100];
		for (int i = 0; i < 100; i++)
		{
			layer1[i].setNumWeights(784);
			//layer1d[i].setNumWeights(784);
			//layer1s[i].setNumWeights(784);
		}
		NeuronD* layer2 = new NeuronD[10];
		//NeuronD* layer2d = new NeuronD[10];
		//Neuron* layer2s = new Neuron[10];
		for (int i = 0; i < 10; i++)
		{
			layer2[i].setNumWeights(100);
			//layer2d[i].setNumWeights(100);
			//layer2s[i].setNumWeights(100);
		}
		double** checkingdata = new double*[10000];
		//StochasticNum** checkingdatas = new StochasticNum*[10000];
		//double** checkingdatad = new double*[10000];
		int labels[10000];

		for (int i = 0; i < 10000; i++)
		{
			checkingdata[i] = new double[784];
			//checkingdatas[i] = new StochasticNum[784];
			//checkingdatad[i] = new double[784];
		}
		if (ifile.fail()) {
			std::cerr << "There was a problem opening the input file!\n";
			std::exit(1);
		}
		std::string snum;
		//Load input weights
		while (ifile.peek() != EOF)
		{
			for (int i = 0; i < 100; i++)
			{
				double* weights = new double[784];
				//StochasticNum* weightss = new StochasticNum[784];
				//double* weightsd = new double[784];
				for (int j = 0; j < 784; j++)
				{
					ifile >> snum;
					char check = snum.at(0);
					while (check != '0' && check != '1' && check != '2' && check != '-')
					{
						snum.erase(0, 1);
						check = snum.at(0);
						if (snum.length() == 0)
							continue;
					}
					if (snum.length() == 0)
					{
						j--;
						continue;
					}
					weights[j] = std::stod(snum);
					//weightsd[j] = d;

				//layer1d[i].setWeight(weightsd);
				//layer1s[i].setWeight(weightss);
				layer1[i].setWeight(weights);
			}
		}
		ifile.close();
		std::cout << "Weights 1 loaded" << std::endl;

		ifile.open("bias1.txt");

		if (!ifile.is_open()) {
			std::cerr << "There was a problem opening the input file!\n";
			std::exit(1);
		}
		//Load input biases
		while (ifile.peek() != EOF)
		{
			for (int i = 0; i < 100; i++)
			{
				ifile >> snum;
				layer1[i].setBias(new double(std::stod(snum)));
				//layer1d[i].setBias(new double(d));
			}
		}
		ifile.close();
		std::cout << "Biases 1 loaded" << std::endl;

		ifile.open("W2.txt");
		if (ifile.fail()) {
			std::cerr << "There was a problem opening the input file!\n";
			std::exit(1);
		}
		//Load output weights
		while (ifile.peek() != EOF)
		{
			for (int i = 0; i < 10; i++)
			{
				double* weight2 = new double[100];
				//StochasticNum* weight2s = new StochasticNum[100];
				//double* weight2d = new double[100];
				for (int j = 0; j < 100; j++)
				{
					ifile >> snum;
					char check = snum.at(0);
					while (check != '0' && check != '1' && check != '2' && check != '-')
					{
						snum.erase(0, 1);
						check = snum.at(0);
						if (snum.length() == 0)
							continue;
					}
					if (snum.length() == 0)
					{
						j--;
						continue;
					}
					weight2[j] = std::stod(snum);
					
				}
				layer2[i].setWeight(weight2);
				//layer2d[i].setWeight(weight2d);
				//layer2s[i].setWeight(weight2s);
			}
		}
		ifile.close();
		std::cout << "Weights 2 loaded" << std::endl;

		ifile.open("bias2.txt");

		if (!ifile.is_open()) {
			std::cerr << "There was a problem opening the input file!\n";
			std::exit(1);
		}
		//Load output biases
		while (ifile.peek() != EOF)
		{
			for (int i = 0; i < 10; i++)
			{
				ifile >> snum;
				double d = std::stod(snum);
				//layer2d[i].setBias(new double(d));
				if (d < 0)
				{
					layer2[i].setBias(new double(d));
					//layer2s[i].setBias(new double(d));
				}
				else
				{
					layer2[i].setBias(new double(d));
					//layer2s[i].setBias(new double(d));//, BIT_LENGTH));
				}
			}
		}
		ifile.close();
		std::cout << "Biases 2 loaded" << std::endl;
		ifile.open("images.txt");

		if (!ifile.is_open()) {
			std::cerr << "There was a problem opening the input file!\n";
			std::exit(1);
		}
		//load images
		while (ifile.peek() != EOF)
		{
			for (int i = 0; i < 10000; i++)
			{
				for (int j = 0; j < 784; j++)
				{
					ifile >> snum;
					char check = snum.at(0);
					while (check != '0' && check != '1' && check != '2' && check != '-')
					{
						snum.erase(0, 1);
						check = snum.at(0);
						if (snum.length() == 0)
							continue;
					}
					if (snum.length() == 0)
					{
						j--;
						continue;
					}
					//checkingdatad[i][j] = stod(snum);
					//checkingdatas[i][j].setValue(stod(snum), BIT_LENGTH, false);
					checkingdata[i][j] = (std::stod(snum));
				}
			}
		}
		ifile.close();
		std::cout << "Images loaded" << std::endl;
		ifile.open("labels.txt");

		if (!ifile.is_open()) {
			std::cerr << "There was a problem opening the input file!\n";
			std::exit(1);
		}
		//Load labels
		while (ifile.peek() != EOF)
		{
			for (int i = 0; i < 10000; i++)
			{
				for (int j = 0; j < 10; j++)
				{
					ifile >> snum;
					if (std::stod(snum) == 1)
					{
						labels[i] = j;
					}
				}
			}
		}
		ifile.close();
		std::cout << "Labels loaded" << std::endl;
		std::cout << "All loaded into neural net!" << std::endl;

		int correct = 0;
		//int dcorrect = 0;
		//int scorrect = 0;

		//double layer1error = 0;
		//double layer2error = 0;

		int total = 0;
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 100; j++)
			{
				layer1[j].setInput(checkingdata[i]);
				//layer1d[j].setInput(checkingdatad[i]);
				//layer1s[j].setInput(checkingdatas[i]);
			}
			double layer1out[100];

			//double layer1outs[100];
			//StochasticNum layer1trueouts[100];

			//double layer1dout[100];

			double totalout[10];
			//double totaloutd[10];
			//double totalouts[10];
			double layer1max = 0;
			//double layer1maxd = 0;
			//double layer1maxs = 0;
			double layer2max = 0;
			//double layer2maxd = 0;
			//double layer2maxs = 0;
			for (int j = 0; j < 100; j++)
			{
				layer1out[j] = layer1[j].think();
				/*layer1dout[j] = layer1d[j].think();
				if (layer1dout[j] < 0)
				layer1dout[j] = 0;
				layer1outs[j] = layer1s[j].think();
				if (layer1outs[j] < 0)
				layer1outs[j] = 0;
				*/
				if (layer1out[j] > layer1max)
					layer1max = layer1out[j];
				/*if (layer1dout[j] > layer1maxd)
				layer1maxd = layer1dout[j];
				if (layer1outs[j] > layer1maxs)
				layer1maxs = layer1outs[j];*/
			}
			for (int j = 0; j < 100; j++)
			{
				layer1out[j] = layer1out[j] / layer1max;
				//layer1dout[j] = layer1dout[j] / layer1maxd;
				//layer1outs[j] = layer1outs[j] / layer1maxs;
				//layer1trueouts[j] = StochasticNum(layer1outs[j], BIT_LENGTH, false);
			}
			for (int j = 0; j < 100; j++)
			{
				//std::cout << abs(layer1trueout[j].getDoubleValue() - layer1dout[j]) << " " << abs(layer1trueouts[j].getDoubleValue() - layer1dout[j]) << std::endl;
			}
			for (int j = 0; j < 10; j++)
			{
				layer2[j].setInput(layer1out);
				//layer2d[j].setInput(layer1dout);
				//layer2s[j].setInput(layer1trueouts);
			}
			double maxtotout = 0;
			int index = 0;
			double maxtotoutd = 0;
			int indexd = 0;
			double maxtotouts = 0;
			int indexs = 0;
			for (int j = 0; j < 10; j++)
			{
				totalout[j] = layer2[j].think();
				//totaloutd[j] = layer2d[j].think();
				//totalouts[j] = layer2s[j].think();
				if (totalout[j] > maxtotout)
				{
					maxtotout = totalout[j];
					index = j;
				}
				/*if (totaloutd[j] > maxtotoutd)
				{
				maxtotoutd = totaloutd[j];
				indexd = j;
				}
				if (totalouts[j] > maxtotouts)
				{
				maxtotouts = totalouts[j];
				indexs = j;
				}*/
			}
			for (int j = 0; j < 10; j++)
			{
				totalout[j] = totalout[j] / maxtotout;
				//totaloutd[j] = totaloutd[j] / maxtotoutd;
				//totalouts[j] = totalouts[j] / maxtotouts;
			}
			if (index == labels[i])
			{
				correct++;
			}
			/*if (indexd == labels[i])
			{
			dcorrect++;
			}
			if (indexs == labels[i])
			{
			scorrect++;
			}*/
			total++;
			//std::cout << "======" << std::endl;
		}
		std::cout << "TOTAL CORRECT: " << (double)correct / (double)total << std::endl;//<< " BITSET COORECT: " << (double)scorrect / (double)total << " DOUBLE COORECT: " << (double)dcorrect / (double)total << std::endl;
																					   //std::cout << "LAYER 1 ERROR: " << layer1error / (double)10000 << " LAYER 2 ERROR: " << layer2error / (double)10000 << std::endl;
		for (int i = 0; i < 10000; ++i) {
			delete[] checkingdata[i];
			//delete[] checkingdatad[i];
		}
		delete[] checkingdata;
		//delete[] checkingdatad;
	}

}
void mnist_64()
{
	std::ifstream ifile;
	ifile.open("W1.txt");

	Neuron64* layer1 = new Neuron64[100];
	//NeuronD* layer1d = new NeuronD[100];
	//Neuron* layer1s = new Neuron[100];
	for (int i = 0; i < 100; i++)
	{
		layer1[i].setNumWeights(784);
		//layer1d[i].setNumWeights(784);
		//layer1s[i].setNumWeights(784);
	}
	Neuron64* layer2 = new Neuron64[10];
	//NeuronD* layer2d = new NeuronD[10];
	//Neuron* layer2s = new Neuron[10];
	for (int i = 0; i < 10; i++)
	{
		layer2[i].setNumWeights(100);
		//layer2d[i].setNumWeights(100);
		//layer2s[i].setNumWeights(100);
	}
	StochasticNum64** checkingdata = new StochasticNum64*[10000];
	//StochasticNum** checkingdatas = new StochasticNum*[10000];
	//double** checkingdatad = new double*[10000];
	int labels[10000];

	for (int i = 0; i < 10000; i++)
	{
		checkingdata[i] = new StochasticNum64[784];
		//checkingdatas[i] = new StochasticNum[784];
		//checkingdatad[i] = new double[784];
	}
	if (ifile.fail()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	std::string snum;
	//Load input weights
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 100; i++)
		{
			StochasticNum64* weights = new StochasticNum64[784];
			//StochasticNum* weightss = new StochasticNum[784];
			//double* weightsd = new double[784];
			for (int j = 0; j < 784; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				double d = std::stod(snum);
				//weightsd[j] = d;
				if (d < 0)
				{
					//weightss[j].setValue(-1 * d, BIT_LENGTH, true);
					weights[j].setValue((-1 * d), true, 2);
				}
				else
				{
					//weightss[j].setValue(d, BIT_LENGTH, false);
					weights[j].setValue(d, false, 2);
				}
			}
			//layer1d[i].setWeight(weightsd);
			//layer1s[i].setWeight(weightss);
			layer1[i].setWeight(weights);
		}
	}
	ifile.close();
	std::cout << "Weights 1 loaded" << std::endl;

	ifile.open("bias1.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load input biases
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 100; i++)
		{
			ifile >> snum;
			double d = std::stod(snum);
			//layer1d[i].setBias(new double(d));
			if (d < 0)
			{
				//layer1s[i].setBias(new double(d));
				layer1[i].setBias(new double(d));
			}
			else
			{
				layer1[i].setBias(new double(d));
				//layer1s[i].setBias(new double(d));
			}
		}
	}
	ifile.close();
	std::cout << "Biases 1 loaded" << std::endl;

	ifile.open("W2.txt");
	if (ifile.fail()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load output weights
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10; i++)
		{
			StochasticNum64* weight2 = new StochasticNum64[100];
			//StochasticNum* weight2s = new StochasticNum[100];
			//double* weight2d = new double[100];
			for (int j = 0; j < 100; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				double d = std::stod(snum);
				//weight2d[j] = d;
				if (d < 0)
				{
					//weight2s[j].setValue(d * -1, BIT_LENGTH, true);
					weight2[j].setValue(d * -1, true, 2);
				}
				else
				{
					//weight2s[j].setValue(d * -1, BIT_LENGTH, false);
					weight2[j].setValue(d, false, 2);

				}
			}
			layer2[i].setWeight(weight2);
			//layer2d[i].setWeight(weight2d);
			//layer2s[i].setWeight(weight2s);
		}
	}
	ifile.close();
	std::cout << "Weights 2 loaded" << std::endl;

	ifile.open("bias2.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load output biases
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10; i++)
		{
			ifile >> snum;
			double d = std::stod(snum);
			//layer2d[i].setBias(new double(d));
			if (d < 0)
			{
				layer2[i].setBias(new double(d));
				//layer2s[i].setBias(new double(d));
			}
			else
			{
				layer2[i].setBias(new double(d));
				//layer2s[i].setBias(new double(d));//, BIT_LENGTH));
			}
		}
	}
	ifile.close();
	std::cout << "Biases 2 loaded" << std::endl;
	ifile.open("images.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//load images
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 784; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				//checkingdatad[i][j] = stod(snum);
				//checkingdatas[i][j].setValue(stod(snum), BIT_LENGTH, false);
				checkingdata[i][j].setValue(std::stod(snum), false);
			}
		}
	}
	ifile.close();
	std::cout << "Images loaded" << std::endl;
	ifile.open("labels.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load labels
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				ifile >> snum;
				if (std::stod(snum) == 1)
				{
					labels[i] = j;
				}
			}
		}
	}
	ifile.close();
	std::cout << "Labels loaded" << std::endl;
	std::cout << "All loaded into neural net!" << std::endl;

	int correct = 0;
	//int dcorrect = 0;
	//int scorrect = 0;

	//double layer1error = 0;
	//double layer2error = 0;

	int total = 0;
	for (int i = 0; i < 10000; i++)
	{
		for (int j = 0; j < 100; j++)
		{
			layer1[j].setInput(checkingdata[i]);
			//layer1d[j].setInput(checkingdatad[i]);
			//layer1s[j].setInput(checkingdatas[i]);
		}
		double layer1out[100];
		StochasticNum64 layer1trueout[100];

		//double layer1outs[100];
		//StochasticNum layer1trueouts[100];

		//double layer1dout[100];

		double totalout[10];
		//double totaloutd[10];
		//double totalouts[10];
		double layer1max = 0;
		//double layer1maxd = 0;
		//double layer1maxs = 0;
		double layer2max = 0;
		//double layer2maxd = 0;
		//double layer2maxs = 0;
		for (int j = 0; j < 100; j++)
		{
			layer1out[j] = layer1[j].think();
			/*layer1dout[j] = layer1d[j].think();
			if (layer1dout[j] < 0)
			layer1dout[j] = 0;
			layer1outs[j] = layer1s[j].think();
			if (layer1outs[j] < 0)
			layer1outs[j] = 0;
			*/
			if (layer1out[j] > layer1max)
				layer1max = layer1out[j];
			/*if (layer1dout[j] > layer1maxd)
			layer1maxd = layer1dout[j];
			if (layer1outs[j] > layer1maxs)
			layer1maxs = layer1outs[j];*/
		}
		for (int j = 0; j < 100; j++)
		{
			layer1out[j] = layer1out[j] / layer1max;
			//layer1dout[j] = layer1dout[j] / layer1maxd;
			layer1trueout[j] = StochasticNum64(layer1out[j], false);
			//layer1outs[j] = layer1outs[j] / layer1maxs;
			//layer1trueouts[j] = StochasticNum(layer1outs[j], BIT_LENGTH, false);
		}
		for (int j = 0; j < 100; j++)
		{
			//std::cout << abs(layer1trueout[j].getDoubleValue() - layer1dout[j]) << " " << abs(layer1trueouts[j].getDoubleValue() - layer1dout[j]) << std::endl;
		}
		for (int j = 0; j < 10; j++)
		{
			layer2[j].setInput(layer1trueout);
			//layer2d[j].setInput(layer1dout);
			//layer2s[j].setInput(layer1trueouts);
		}
		double maxtotout = 0;
		int index = 0;
		double maxtotoutd = 0;
		int indexd = 0;
		double maxtotouts = 0;
		int indexs = 0;
		for (int j = 0; j < 10; j++)
		{
			totalout[j] = layer2[j].think();
			//totaloutd[j] = layer2d[j].think();
			//totalouts[j] = layer2s[j].think();
			if (totalout[j] > maxtotout)
			{
				maxtotout = totalout[j];
				index = j;
			}
			/*if (totaloutd[j] > maxtotoutd)
			{
			maxtotoutd = totaloutd[j];
			indexd = j;
			}
			if (totalouts[j] > maxtotouts)
			{
			maxtotouts = totalouts[j];
			indexs = j;
			}*/
		}
		for (int j = 0; j < 10; j++)
		{
			totalout[j] = totalout[j] / maxtotout;
			//totaloutd[j] = totaloutd[j] / maxtotoutd;
			//totalouts[j] = totalouts[j] / maxtotouts;
		}
		if (index == labels[i])
		{
			correct++;
		}
		/*if (indexd == labels[i])
		{
		dcorrect++;
		}
		if (indexs == labels[i])
		{
		scorrect++;
		}*/
		total++;
		//std::cout << "======" << std::endl;
	}
	std::cout << "TOTAL CORRECT: " << (double)correct / (double)total << std::endl;//<< " BITSET COORECT: " << (double)scorrect / (double)total << " DOUBLE COORECT: " << (double)dcorrect / (double)total << std::endl;
																				   //std::cout << "LAYER 1 ERROR: " << layer1error / (double)10000 << " LAYER 2 ERROR: " << layer2error / (double)10000 << std::endl;
	for (int i = 0; i < 10000; ++i) {
		delete[] checkingdata[i];
		//delete[] checkingdatad[i];
	}
	delete[] checkingdata;
	//delete[] checkingdatad;
}

void mnist_128()
{
	std::ifstream ifile;
	ifile.open("W1.txt");

	Neuron128* layer1 = new Neuron128[100];
	//NeuronD* layer1d = new NeuronD[100];
	//Neuron* layer1s = new Neuron[100];
	for (int i = 0; i < 100; i++)
	{
		layer1[i].setNumWeights(784);
		//layer1d[i].setNumWeights(784);
		//layer1s[i].setNumWeights(784);
	}
	Neuron128* layer2 = new Neuron128[10];
	//NeuronD* layer2d = new NeuronD[10];
	//Neuron* layer2s = new Neuron[10];
	for (int i = 0; i < 10; i++)
	{
		layer2[i].setNumWeights(100);
		//layer2d[i].setNumWeights(100);
		//layer2s[i].setNumWeights(100);
	}
	StochasticNum128** checkingdata = new StochasticNum128*[10000];
	//StochasticNum** checkingdatas = new StochasticNum*[10000];
	//double** checkingdatad = new double*[10000];
	int labels[10000];

	for (int i = 0; i < 10000; i++)
	{
		checkingdata[i] = new StochasticNum128[784];
		//checkingdatas[i] = new StochasticNum[784];
		//checkingdatad[i] = new double[784];
	}
	if (ifile.fail()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	std::string snum;
	//Load input weights
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 100; i++)
		{
			StochasticNum128* weights = new StochasticNum128[784];
			//StochasticNum* weightss = new StochasticNum[784];
			//double* weightsd = new double[784];
			for (int j = 0; j < 784; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				double d = std::stod(snum);
				//weightsd[j] = d;
				if (d < 0)
				{
					//weightss[j].setValue(-1 * d, BIT_LENGTH, true);
					weights[j].setValue((-1 * d), true, 2);
				}
				else
				{
					//weightss[j].setValue(d, BIT_LENGTH, false);
					weights[j].setValue(d, false, 2);
				}
			}
			//layer1d[i].setWeight(weightsd);
			//layer1s[i].setWeight(weightss);
			layer1[i].setWeight(weights);
		}
	}
	ifile.close();
	std::cout << "Weights 1 loaded" << std::endl;

	ifile.open("bias1.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load input biases
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 100; i++)
		{
			ifile >> snum;
			double d = std::stod(snum);
			//layer1d[i].setBias(new double(d));
			if (d < 0)
			{
				//layer1s[i].setBias(new double(d));
				layer1[i].setBias(new double(d));
			}
			else
			{
				layer1[i].setBias(new double(d));
				//layer1s[i].setBias(new double(d));
			}
		}
	}
	ifile.close();
	std::cout << "Biases 1 loaded" << std::endl;

	ifile.open("W2.txt");
	if (ifile.fail()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load output weights
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10; i++)
		{
			StochasticNum128* weight2 = new StochasticNum128[100];
			//StochasticNum* weight2s = new StochasticNum[100];
			//double* weight2d = new double[100];
			for (int j = 0; j < 100; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				double d = std::stod(snum);
				//weight2d[j] = d;
				if (d < 0)
				{
					//weight2s[j].setValue(d * -1, BIT_LENGTH, true);
					weight2[j].setValue(d * -1, true, 2);
				}
				else
				{
					//weight2s[j].setValue(d * -1, BIT_LENGTH, false);
					weight2[j].setValue(d, false, 2);

				}
			}
			layer2[i].setWeight(weight2);
			//layer2d[i].setWeight(weight2d);
			//layer2s[i].setWeight(weight2s);
		}
	}
	ifile.close();
	std::cout << "Weights 2 loaded" << std::endl;

	ifile.open("bias2.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load output biases
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10; i++)
		{
			ifile >> snum;
			double d = std::stod(snum);
			//layer2d[i].setBias(new double(d));
			if (d < 0)
			{
				layer2[i].setBias(new double(d));
				//layer2s[i].setBias(new double(d));
			}
			else
			{
				layer2[i].setBias(new double(d));
				//layer2s[i].setBias(new double(d));//, BIT_LENGTH));
			}
		}
	}
	ifile.close();
	std::cout << "Biases 2 loaded" << std::endl;
	ifile.open("images.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//load images
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 784; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				//checkingdatad[i][j] = stod(snum);
				//checkingdatas[i][j].setValue(stod(snum), BIT_LENGTH, false);
				checkingdata[i][j].setValue(std::stod(snum), false);
			}
		}
	}
	ifile.close();
	std::cout << "Images loaded" << std::endl;
	ifile.open("labels.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load labels
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				ifile >> snum;
				if (std::stod(snum) == 1)
				{
					labels[i] = j;
				}
			}
		}
	}
	ifile.close();
	std::cout << "Labels loaded" << std::endl;
	std::cout << "All loaded into neural net!" << std::endl;

	int correct = 0;
	//int dcorrect = 0;
	//int scorrect = 0;

	//double layer1error = 0;
	//double layer2error = 0;

	int total = 0;
	for (int i = 0; i < 10000; i++)
	{
		for (int j = 0; j < 100; j++)
		{
			layer1[j].setInput(checkingdata[i]);
			//layer1d[j].setInput(checkingdatad[i]);
			//layer1s[j].setInput(checkingdatas[i]);
		}
		double layer1out[100];
		StochasticNum128 layer1trueout[100];

		//double layer1outs[100];
		//StochasticNum layer1trueouts[100];

		//double layer1dout[100];

		double totalout[10];
		//double totaloutd[10];
		//double totalouts[10];
		double layer1max = 0;
		//double layer1maxd = 0;
		//double layer1maxs = 0;
		double layer2max = 0;
		//double layer2maxd = 0;
		//double layer2maxs = 0;
		for (int j = 0; j < 100; j++)
		{
			layer1out[j] = layer1[j].think();
			/*layer1dout[j] = layer1d[j].think();
			if (layer1dout[j] < 0)
			layer1dout[j] = 0;
			layer1outs[j] = layer1s[j].think();
			if (layer1outs[j] < 0)
				layer1outs[j] = 0;
				*/
			if (layer1out[j] > layer1max)
				layer1max = layer1out[j];
			/*if (layer1dout[j] > layer1maxd)
			layer1maxd = layer1dout[j];
			if (layer1outs[j] > layer1maxs)
				layer1maxs = layer1outs[j];*/
		}
		for (int j = 0; j < 100; j++)
		{
			layer1out[j] = layer1out[j] / layer1max;
			//layer1dout[j] = layer1dout[j] / layer1maxd;
			layer1trueout[j] = StochasticNum128(layer1out[j], false);
			//layer1outs[j] = layer1outs[j] / layer1maxs;
			//layer1trueouts[j] = StochasticNum(layer1outs[j], BIT_LENGTH, false);
		}
		for (int j = 0; j < 100; j++)
		{
			//std::cout << abs(layer1trueout[j].getDoubleValue() - layer1dout[j]) << " " << abs(layer1trueouts[j].getDoubleValue() - layer1dout[j]) << std::endl;
		}
		for (int j = 0; j < 10; j++)
		{
			layer2[j].setInput(layer1trueout);
			//layer2d[j].setInput(layer1dout);
			//layer2s[j].setInput(layer1trueouts);
		}
		double maxtotout = 0;
		int index = 0;
		double maxtotoutd = 0;
		int indexd = 0;
		double maxtotouts = 0;
		int indexs = 0;
		for (int j = 0; j < 10; j++)
		{
			totalout[j] = layer2[j].think();
			//totaloutd[j] = layer2d[j].think();
			//totalouts[j] = layer2s[j].think();
			if (totalout[j] > maxtotout)
			{
				maxtotout = totalout[j];
				index = j;
			}
			/*if (totaloutd[j] > maxtotoutd)
			{
				maxtotoutd = totaloutd[j];
				indexd = j;
			}
			if (totalouts[j] > maxtotouts)
			{
				maxtotouts = totalouts[j];
				indexs = j;
			}*/
		}
		for (int j = 0; j < 10; j++)
		{
			totalout[j] = totalout[j] / maxtotout;
			//totaloutd[j] = totaloutd[j] / maxtotoutd;
			//totalouts[j] = totalouts[j] / maxtotouts;
		}
		if (index == labels[i])
		{
			correct++;
		}
		/*if (indexd == labels[i])
		{
			dcorrect++;
		}
		if (indexs == labels[i])
		{
			scorrect++;
		}*/
		total++;
		//std::cout << "======" << std::endl;
	}
	std::cout << "TOTAL CORRECT: " << (double)correct / (double)total << std::endl;//<< " BITSET COORECT: " << (double)scorrect / (double)total << " DOUBLE COORECT: " << (double)dcorrect / (double)total << std::endl;
	//std::cout << "LAYER 1 ERROR: " << layer1error / (double)10000 << " LAYER 2 ERROR: " << layer2error / (double)10000 << std::endl;
	for (int i = 0; i < 10000; ++i) {
		delete[] checkingdata[i];
		//delete[] checkingdatad[i];
	}
	delete[] checkingdata;
	//delete[] checkingdatad;
}
void mnist_streaming()
{
	std::ifstream ifile;
	ifile.open("W1.txt");

	StreamingNeuron* layer1 = new StreamingNeuron[100];
	for (int i = 0; i < 100; i++)
	{
		layer1[i].setNumWeights(784);
	}
	StreamingNeuron* layer2 = new StreamingNeuron[10];
	for (int i = 0; i < 10; i++)
	{
		layer2[i].setNumWeights(100);
	}
	StochasticNum128** checkingdata = new StochasticNum128*[10000];
	int labels[10000];

	for (int i = 0; i < 10000; i++)
	{
		checkingdata[i] = new StochasticNum128[784];
	}
	if (ifile.fail()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	std::string snum;
	//Load input weights
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 100; i++)
		{
			StochasticNum128* weights = new StochasticNum128[784];
			for (int j = 0; j < 784; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				double d = std::stod(snum);
				if (d < 0)
				{
					weights[j].setValue((-1 * d), true, 2);
				}
				else
				{
					weights[j].setValue(d, false, 2);
				}
			}
			layer1[i].setWeight(weights);
		}
	}
	ifile.close();
	std::cout << "Weights 1 loaded" << std::endl;

	ifile.open("bias1.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load input biases
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 100; i++)
		{
			ifile >> snum;
			double d = std::stod(snum);
			if (d < 0)
			{
				layer1[i].setBias(new double(d));
			}
			else
			{
				layer1[i].setBias(new double(d));
			}
		}
	}
	ifile.close();
	std::cout << "Biases 1 loaded" << std::endl;

	ifile.open("W2.txt");
	if (ifile.fail()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load output weights
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10; i++)
		{
			StochasticNum128* weight2 = new StochasticNum128[100];
			for (int j = 0; j < 100; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				double d = std::stod(snum);
				if (d < 0)
				{
					weight2[j].setValue(d * -1, true, 2);
				}
				else
				{
					weight2[j].setValue(d, false, 2);
				}
			}
			layer2[i].setWeight(weight2);
		}
	}
	ifile.close();
	std::cout << "Weights 2 loaded" << std::endl;

	ifile.open("bias2.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load output biases
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10; i++)
		{
			ifile >> snum;
			double d = std::stod(snum);
			if (d < 0)
			{
				layer2[i].setBias(new double(d));
			}
			else
			{
				layer2[i].setBias(new double(d));
			}
		}
	}
	ifile.close();
	std::cout << "Biases 2 loaded" << std::endl;
	ifile.open("images.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//load images
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 784; j++)
			{
				ifile >> snum;
				char check = snum.at(0);
				while (check != '0' && check != '1' && check != '2' && check != '-')
				{
					snum.erase(0, 1);
					check = snum.at(0);
					if (snum.length() == 0)
						continue;
				}
				if (snum.length() == 0)
				{
					j--;
					continue;
				}
				checkingdata[i][j].setValue(std::stod(snum), false);
			}
		}
	}
	ifile.close();
	std::cout << "Images loaded" << std::endl;
	ifile.open("labels.txt");

	if (!ifile.is_open()) {
		std::cerr << "There was a problem opening the input file!\n";
		std::exit(1);
	}
	//Load labels
	while (ifile.peek() != EOF)
	{
		for (int i = 0; i < 10000; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				ifile >> snum;
				if (std::stod(snum) == 1)
				{
					labels[i] = j;
				}
			}
		}
	}
	ifile.close();
	std::cout << "Labels loaded" << std::endl;
	std::cout << "All loaded into neural net!" << std::endl;

	int correct = 0;
	int total = 0;
	for (int i = 0; i < 10000; i++)
	{
		for (int j = 0; j < 100; j++)
		{
			layer1[j].setInput(checkingdata[i]);
		}
		double layer1out[100] = { 0 };
		StochasticNum128 layer1trueout[100];

		double totalout[10] = { 0 };
		double layer1max = 0;
		double layer2max = 0;

		double maxtotout = 0;
		int index = -1;
		int index2 = -2;
		int index3 = -3;
		int index4 = -4;
		//Begin calculations
		bool iscomplete = false;
		for (int runs = 0; runs < 8 && !iscomplete; runs = runs + 2)
		{
			for (int j = 0; j < 100; j++)
			{
				layer1out[j] = layer1[j].think(runs);
				if (layer1out[j] > layer1max)
					layer1max = layer1out[j];
			}
			for (int j = 0; j < 100; j++)
			{
				layer1out[j] = layer1out[j] / layer1max;
				layer1trueout[j] = StochasticNum128(layer1out[j], false);
				//std::cout << layer1trueout[j].getDoubleValue() << std::endl;
			}
			for (int j = 0; j < 10; j++)
			{
				layer2[j].setInput(layer1trueout);
			}
			for (int j = 0; j < 10; j++)
			{
				totalout[j] += layer2[j].think(runs);
				if (totalout[j] > maxtotout)
				{
					maxtotout = totalout[j];
					index = j;
				}
			}
			for (int j = 0; j < 10; j++)
			{
				totalout[j] = totalout[j] / maxtotout;
			}
			//std::cout << index << " " << index2 << " " << index3 << std::endl;
			if (index == index2 && index3 == index)
			{
				//std::cout << "Guess: " << index << " Value: " << labels[i] << std::endl;
				if (index == labels[i])
					correct++;
				iscomplete = true;
			}
			if (runs == 6 && (index != index2 || index3 != index))
			{
				//std::cout << "Something is wrong!  I don't know what to guess.  I guess " << index << " and the value is " << labels[i] << std::endl;
				if (index == labels[i])
					correct++;
			}
			index3 = index2;
			index2 = index;
		}

		total++;
	}
	std::cout << "TOTAL CORRECT: " << (double)correct / (double)total << std::endl;//<< " BITSET COORECT: " << (double)scorrect / (double)total << " DOUBLE COORECT: " << (double)dcorrect / (double)total << std::endl;
																				   //std::cout << "LAYER 1 ERROR: " << layer1error / (double)10000 << " LAYER 2 ERROR: " << layer2error / (double)10000 << std::endl;
	for (int i = 0; i < 10000; ++i) {
		delete[] checkingdata[i];
		//delete[] checkingdatad[i];
	}
	delete[] checkingdata;
	//delete[] checkingdatad;
}

int main()
{
	//accuracyTests_db();
	//accuracyTests_s128();
	//mnist_d();
	//mnist_streaming();
	//mnist_128();
	mnist_d();
	mnist_64();
	system("pause");
}