#include "NeuronD.h"

using namespace stochastic;
NeuronD::NeuronD()
{
	m_input = nullptr;
	m_bias = nullptr;
	m_weight = nullptr;
}
NeuronD::~NeuronD()
{
	delete[] m_input;
	delete[] m_bias;
	delete[] m_weight;
}
void NeuronD::setInput(double* input)
{
	m_input = input;
}
void NeuronD::setBias(double* biases)
{
	m_bias = biases;
}
void NeuronD::setWeight(double* weights)
{
	m_weight = weights;
}

void NeuronD::assignOneHalf(double* half)
{
	m_onehalf = half;
}
void NeuronD::setNumWeights(int num)
{
	m_numweights = num;
}
double NeuronD::think()
{
	double total = 0;
	for (int i = 0; i < m_numweights; i++)
	{
		double n = m_weight[i] * m_input[i];
		total += n;
	}
	//std::cout << total / 32 << std::endl;
	//std::cout << "ERROR BETWEEN NORMAL AND STOCHASTIC: " << total - total2 << " " << total << " " << total2 << std::endl;
	return total;//StochasticNum((((total)) / 12), 128); // @12 128 47%
}
/*inline const Neuron Neuron::operator* (Neuron& other)
{
return Neuron(m_input * other.m_input, m_bias * other.m_bias, m_weight * other.m_weight);
}
inline const Neuron Neuron::operator+ (Neuron& other)
{
return Neuron(m_input.add(other.m_input, *m_onehalf), m_bias.add(other.m_bias, *m_onehalf), m_weight.add(other.m_weight, *m_onehalf));
}*/