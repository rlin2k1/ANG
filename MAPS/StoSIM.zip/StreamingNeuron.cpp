#include "StreamingNeuron.h"
#include <iostream>
using namespace stochastic;

extern "C" short popcount(short val1, short val2);

StreamingNeuron::StreamingNeuron()
{
	m_input = NULL;
	m_weight = NULL;
	m_bias = NULL;
}
StreamingNeuron::~StreamingNeuron()
{
	delete[] m_input;
	delete[] m_bias;
	delete[] m_weight;
	delete m_onehalf;
}
void StreamingNeuron::setInput(StochasticNum128* input)
{
	m_input = input;
}
void StreamingNeuron::setBias(double* biases)
{
	m_bias = biases;
}
void StreamingNeuron::setWeight(StochasticNum128* weights)
{
	m_weight = weights;
}

void StreamingNeuron::assignOneHalf(double* half)
{
	m_onehalf = half;
}
void StreamingNeuron::setNumWeights(int num)
{
	m_numweights = num;
}
double StreamingNeuron::think(int num)
{
	short total = 0;
	for (int i = 0; i < m_numweights; i++)
	{
		short c = m_input[i].m_bits[num] & m_weight[i].m_bits[num];
		short q = m_input[i].m_bits[num + 1] & m_weight[i].m_bits[num + 1];
		bool a = (long)1 & m_input[i].m_bits[7];
		bool b = (long)1 & m_weight[i].m_bits[7];
		//short t = 0;
		short t = popcount(c, q);
		//t += __popcnt16(c);
		//t += __popcnt16(q);
		//if ((t - t2) != 0)
			//std::cout << "problem " << i << " " << t << " " << t2 << std::endl;
		if ((a && !b) || (!a && b)&& (c != 0))
		{
			t -= 1;
			t *= -1;
		}
		total += t;
	}
	if (total < 0)
		return 0;
	return (total);
}