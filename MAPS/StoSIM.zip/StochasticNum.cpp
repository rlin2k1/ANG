#include <boost\random.hpp>
#include "StochasticNum.h"

using namespace boost::random;
using namespace stochastic;

StochasticNum::StochasticNum()
{}
StochasticNum::StochasticNum(double value, long size, bool isNeg) : m_bits(size + 1), m_size(size)
{
	uint8_t xor;
	double rng;
	for (int i = 0; i < size; i++)
	{
		xor = xor8();
		rng = (double) xor / (double)UINT8_MAX;
		if (rng < value)
			m_bits[i] = 1;
	}
	m_bits[size] = isNeg;
}

StochasticNum::StochasticNum(boost::dynamic_bitset<>& bits)
{
	m_size = bits.size();
	m_bits = bits;

}
size_t StochasticNum::getSize()
{
	return m_size;
}
void StochasticNum::setValue(double value, long size, bool isneg)
{
	m_bits.resize(size + 1);
	if (value == 0)
	{
		m_bits.reset();
		return;
	}
	uint8_t xor;
	double rng;
	for (int i = 0; i < size; i++)
	{
		xor = xor8();
		rng = (double) xor / (double)UINT8_MAX;
		if (rng < value)
			m_bits[i] = 1;
	}
	m_bits[size] = isneg;
}
double StochasticNum::getDoubleValue() const
{
	double i = 0;
	if (m_bits[m_bits.size() - 1] == 0)
		i = 1;
	else
		i = -1;
	return (double)m_bits.count() / (double)m_bits.size() * i;
}
boost::dynamic_bitset<>* StochasticNum::getBits()
{
	return &m_bits;
}
const StochasticNum StochasticNum::add(StochasticNum& other, StochasticNum& select)
{
	return StochasticNum((other.m_bits &= ~select.m_bits) |= (m_bits &= select.m_bits));
}