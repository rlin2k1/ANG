#include "Neuron.h"
using namespace stochastic;
Neuron::Neuron()
{
	m_input = nullptr;
	m_weight = nullptr;
	m_bias = nullptr;
}
Neuron::~Neuron()
{
	delete[] m_input;
	delete[] m_bias;
	delete[] m_weight;

}
void Neuron::setInput(StochasticNum* input)
{
	m_input = input;
}
void Neuron::setBias(double* biases)
{
	m_bias = biases;
}
void Neuron::setWeight(StochasticNum* weights)
{
	m_weight = weights;
}

void Neuron::assignOneHalf(double* half)
{
	m_onehalf = half;
}
void Neuron::setNumWeights(int num)
{
	m_numweights = num;
}
double Neuron::think()
{
	double total = 0;
	for (int i = 0; i < m_numweights; i++)
	{
		StochasticNum c = m_input[i] * m_weight[i];

		total += c.getDoubleValue();
	}
	return (total);//StochasticNum((((total)) / 12), 128); // @12 128 47%
}