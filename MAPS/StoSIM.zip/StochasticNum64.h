#ifndef STOCHASTICNUM64_H
#define STOCHASTICNUM64_H

#include "randoms.h"

extern "C" short popcount64(long long value);

namespace stochastic
{

	class StochasticNum64
	{
	public:
		StochasticNum64();
		StochasticNum64(double value, bool isNeg);
		StochasticNum64(double value, bool isNeg, int flag);
		StochasticNum64(long long bits);
		void setValue(double value, bool isneg);
		void setValue(double value, bool isneg, int flag);
		inline double getDoubleValue() const
		{
			double total = 0;
			int neg = 1;
			total = popcount64(m_bits);
			
			if ((m_bits & (long)1) == 1)
			{
				total--;
				neg = -1;
			}
			return total * 0.015625 * (double)neg;
		}
		inline const StochasticNum64 operator* (const StochasticNum64& other)
		{
			long long bits;
			bits = m_bits & other.m_bits;
			
			long long a = (long long)1 & m_bits;
			long long b = (long long)1 & other.m_bits;
			bits = bits | (a ^ b);
			return StochasticNum64(bits);
		}
		const StochasticNum64 add(StochasticNum64& other, StochasticNum64& select);


	public:
		long long m_bits;
	};
}
#endif