#include "StochasticNum128.h"

using namespace stochastic;

StochasticNum128::StochasticNum128()
{
}
StochasticNum128::StochasticNum128(short bits[8])
{
	m_bits[0] = bits[0];
	m_bits[1] = bits[1];
	m_bits[2] = bits[2];
	m_bits[3] = bits[3]; 
	m_bits[4] = bits[4];
	m_bits[5] = bits[5];
	m_bits[6] = bits[6];
	m_bits[7] = bits[7];

}
StochasticNum128::StochasticNum128(double value, bool isneg)
{
	uint8_t x;
	double rng;
	for (int i = 0; i < 8; i++)
	{
		m_bits[i] = 0;
		for (int j = 0; j < 16; j++)
		{
			x = xor8();
			rng = (double) x * 0.0039;
			if (rng < value)
				m_bits[i] |= ((long)1 << j);
		}
	}
	m_bits[7] &= 0xFFFE;
	m_bits[7] |= (long)isneg;
}
StochasticNum128::StochasticNum128(double value, bool isneg, int flag)
{
	if (flag == 1)
	{
		uint8_t x;
		double rng;
		for (int i = 0; i < 2; i++)
		{
			m_bits[i] = 0;
			for (int j = 0; j < 16; j++)
			{
				x = xor8();
				rng = (double) x * 0.0039;
				if (rng < value)
					m_bits[i] |= ((long)1 << j);
			}
		}
		m_bits[2] = m_bits[0];
		m_bits[3] = m_bits[1];
		m_bits[4] = m_bits[0];
		m_bits[5] = m_bits[1];
		m_bits[6] = m_bits[0];
		m_bits[7] = m_bits[1];
		m_bits[7] &= 0xFFFE;
		m_bits[7] |= (long)isneg;
	}
	else 
	{
		uint8_t x;
		double rng;
		for (int i = 0; i < 4; i++)
		{
			m_bits[i] = 0;
			for (int j = 0; j < 16; j++)
			{
				x = xor8();
				rng = (double) x * 0.0039;
				if (rng < value)
					m_bits[i] |= ((long)1 << j);
			}
		}
		m_bits[4] = m_bits[0];
		m_bits[5] = m_bits[1];
		m_bits[6] = m_bits[2];
		m_bits[7] = m_bits[3];
		m_bits[7] &= 0xFFFE;
		m_bits[7] |= (long)isneg;
	}
}
void StochasticNum128::setValue(double value, bool isneg)
{
	uint8_t x;
	double rng;
	for (int i = 0; i < 8; i++)
	{
		m_bits[i] = 0;
		for (int j = 0; j < 16; j++)
		{
			x = xor8();
			rng = (double) x * 0.0039;
			if (rng < value)
				m_bits[i] |= ((long)1 << j);
		}
	}
	m_bits[7] &= 0xFFFE;
	m_bits[7] |= (long)isneg;
}
void StochasticNum128::setValue(double value, bool isneg, int flag)
{
	if (flag == 1)
	{
		uint8_t x;
		double rng;
		for (int i = 0; i < 2; i++)
		{
			m_bits[i] = 0;
			for (int j = 0; j < 16; j++)
			{
				x = xor8();
				rng = (double) x * 0.0039;
				if (rng < value)
					m_bits[i] |= ((long)1 << j);
			}
		}
		m_bits[2] = m_bits[0];
		m_bits[3] = m_bits[1];
		m_bits[4] = m_bits[0];
		m_bits[5] = m_bits[1];
		m_bits[6] = m_bits[0];
		m_bits[7] = m_bits[1];
		m_bits[7] &= 0xFFFE;
		m_bits[7] |= (long)isneg;
	}
	else
	{
		uint8_t x;
		double rng;
		for (int i = 0; i < 4; i++)
		{
			m_bits[i] = 0;
			for (int j = 0; j < 16; j++)
			{
				x = xor8();
				rng = (double) x * 0.0039;
				if (rng < value)
					m_bits[i] |= ((long)1 << j);
			}
		}
		m_bits[4] = m_bits[0];
		m_bits[5] = m_bits[1];
		m_bits[6] = m_bits[2];
		m_bits[7] = m_bits[3];
		m_bits[7] &= 0xFFFE;
		m_bits[7] |= (long)isneg;
	}
}
const StochasticNum128 StochasticNum128::add(StochasticNum128& other, StochasticNum128& select)
{
	short bits[8];
	bits[0] = (other.m_bits[0] &= ~select.m_bits[0]) | (m_bits[0] &= select.m_bits[0]);
	bits[1] = (other.m_bits[1] &= ~select.m_bits[1]) | (m_bits[1] &= select.m_bits[1]);
	bits[2] = (other.m_bits[2] &= ~select.m_bits[2]) | (m_bits[2] &= select.m_bits[2]);
	bits[3] = (other.m_bits[3] &= ~select.m_bits[3]) | (m_bits[3] &= select.m_bits[3]);
	bits[4] = (other.m_bits[4] &= ~select.m_bits[4]) | (m_bits[4] &= select.m_bits[4]);
	bits[5] = (other.m_bits[5] &= ~select.m_bits[5]) | (m_bits[5] &= select.m_bits[5]);
	bits[6] = (other.m_bits[6] &= ~select.m_bits[6]) | (m_bits[6] &= select.m_bits[6]);
	bits[7] = (other.m_bits[7] &= ~select.m_bits[7]) | (m_bits[7] &= select.m_bits[7]);

	return StochasticNum128(bits);
}