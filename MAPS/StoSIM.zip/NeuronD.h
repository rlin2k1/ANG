#ifndef NEUROND_H
#define NEUROND_H

#include "StochasticNum.h"
#include <boost\dynamic_bitset.hpp>
namespace stochastic
{
	class NeuronD
	{
	public:
		~NeuronD();
		NeuronD();

		void setInput(double* input);
		void setBias(double* biases);
		void setWeight(double* weights);
		void setNumWeights(int num);

		void assignOneHalf(double* half);

		double think();

	private:
		int m_numweights;
		double* m_input;
		double* m_bias;
		double* m_weight;
		double* m_onehalf;
	};
}

#endif