#include "Neuron64.h"
#include <cstddef>
using namespace stochastic;

extern "C" short popcount64(long long val);

Neuron64::Neuron64()
{
	m_input = NULL;
	m_weight = NULL;
	m_bias = NULL;
}
Neuron64::~Neuron64()
{
	delete[] m_input;
	delete[] m_bias;
	delete[] m_weight;
	delete m_onehalf;
}
void Neuron64::setInput(StochasticNum64* input)
{
	m_input = input;
}
void Neuron64::setBias(double* biases)
{
	m_bias = biases;
}
void Neuron64::setWeight(StochasticNum64* weights)
{
	m_weight = weights;
}

void Neuron64::assignOneHalf(double* half)
{
	m_onehalf = half;
}
void Neuron64::setNumWeights(int num)
{
	m_numweights = num;
}
double Neuron64::think()
{
	short total = 0;
	for (int i = 0; i < m_numweights; i++)
	{
		StochasticNum64 c = m_input[i] * m_weight[i];
		long long t = popcount64(c.m_bits);
		
		if ((c.m_bits & (long)1) == 1)
		{
			t -= 1;
			t *= -1;
		}
		total += t;
	}
	//std::cout << total << std::endl;
	return (total);//StochasticNum((((total)) / 12), 128); // @12 128 47%
}