#ifndef NEURON128_H
#define NEURON128_H

#include "StochasticNum128.h"
namespace stochastic
{
	class Neuron128
	{
	public:
		~Neuron128();
		Neuron128();

		void setInput(StochasticNum128* input);
		void setBias(double* biases);
		void setWeight(StochasticNum128* weights);
		void setNumWeights(int num);

		void assignOneHalf(double* half);

		double think();

	private:
		int m_numweights;
		StochasticNum128* m_input;
		double* m_bias;
		StochasticNum128* m_weight;
		double* m_onehalf;
	};
}

#endif